# Ijtimoiy Tarmoq

Instagram + Odnoklassniki + Messaging aralash, global, web + mobil (PWA).
Hozir: **Faza 0 — backend poydevor** (auth + PostgreSQL sxema).

## ⚡ Tezkor start (bitta buyruq)

Talab: Docker, Node 20+, pnpm (`npm i -g pnpm`).

```bash
bash setup.sh      # postgres + .env + install + migration — hammasi avtomatik
pnpm dev:api       # serverni ishga tushiradi → http://localhost:4000
```

Boshqa terminalda tekshirish:
```bash
bash smoke-test.sh # barcha auth endpointlarni avtomatik sinaydi
```

## 📂 Tuzilma
```
.
├── apps/api/              # backend (Fastify + Drizzle)
│   └── README.md          # batafsil texnik hujjat
├── docker-compose.yml     # PostgreSQL + Adminer
├── setup.sh               # avtomatik sozlash
└── smoke-test.sh          # end-to-end test
```

To'liq texnik tafsilot: [`apps/api/README.md`](apps/api/README.md)
Yo'l xaritasi: alohida `social_network_yol_xaritasi.md` faylida.

## Keyingi: Faza 1
Profil + Post + Lenta + Like/Izoh + Media (Cloudflare R2).
