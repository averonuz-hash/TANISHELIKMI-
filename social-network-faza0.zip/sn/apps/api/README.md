# Ijtimoiy Tarmoq — Faza 0 (Backend Poydevor)

Auth tizimi + PostgreSQL sxema + Fastify server. Bu — keyingi hamma faza shu ustiga quriladigan asos.

## Stack
- **Fastify** — backend framework
- **Drizzle ORM + PostgreSQL** — ma'lumotlar bazasi
- **bcrypt** — parol xeshlash
- **JWT (access) + httpOnly refresh cookie** — autentifikatsiya, refresh rotatsiyasi bilan
- **Zod** — kiruvchi ma'lumotlarni tekshirish

## Tuzilma
```
apps/api/
├── src/
│   ├── config/env.ts          # .env tekshirish (zod)
│   ├── db/
│   │   ├── schema.ts          # barcha jadvallar (LOYIHA YADROSI)
│   │   ├── index.ts           # DB ulanishi
│   │   └── migrate.ts         # migratsiya skripti
│   ├── plugins/auth.ts        # authenticate guard + cookie helpers
│   ├── utils/
│   │   ├── password.ts        # bcrypt
│   │   └── tokens.ts          # JWT + refresh token
│   ├── modules/
│   │   ├── auth/              # register, login, refresh, logout
│   │   └── users/             # GET /me (himoyalangan)
│   └── index.ts               # server
├── drizzle.config.ts
└── package.json
```

## Ishga tushirish

### 1. PostgreSQL tayyorlang
Lokal yoki Docker orqali:
```bash
docker run --name sn-pg -e POSTGRES_PASSWORD=postgres \
  -e POSTGRES_DB=social_network -p 5432:5432 -d postgres:16
```

### 2. Bog'liqliklarni o'rnating
```bash
# loyiha ildizida
pnpm install
```

### 3. Muhitni sozlang
```bash
cd apps/api
cp .env.example .env
# .env ichidagi JWT_*_SECRET larni uzun random qiymatlarga almashtiring
# masalan: openssl rand -hex 32
```

### 4. Migratsiyani yarating va qo'llang
```bash
pnpm db:generate   # schema.ts dan SQL yaratadi (./drizzle papkasi)
pnpm db:migrate    # bazaga qo'llaydi
```

### 5. Serverni ishga tushiring
```bash
pnpm dev
# 🚀 http://localhost:4000
```

## API Endpointlar

| Metod | Yo'l | Tavsif | Himoya |
|---|---|---|---|
| GET | `/health` | Sog'liq tekshiruvi | — |
| POST | `/auth/register` | Ro'yxatdan o'tish | — |
| POST | `/auth/login` | Kirish | — |
| POST | `/auth/refresh` | Access tokenni yangilash | cookie |
| POST | `/auth/logout` | Chiqish | cookie |
| GET | `/users/me` | Joriy foydalanuvchi | Bearer |

### Misol: ro'yxatdan o'tish
```bash
curl -X POST http://localhost:4000/auth/register \
  -H "Content-Type: application/json" \
  -c cookies.txt \
  -d '{"username":"averon","email":"averon@example.com","password":"parol12345"}'
```
Javob: `{ "user": {...}, "accessToken": "..." }`
Refresh token httpOnly cookie sifatida o'rnatiladi.

### Misol: himoyalangan endpoint
```bash
curl http://localhost:4000/users/me \
  -H "Authorization: Bearer <accessToken>"
```

## Xavfsizlik qarorlari (nima uchun shunday)
- **Access token** qisqa muddatli (15 daqiqa), frontend xotirasida saqlanadi.
- **Refresh token** httpOnly cookie'da — JavaScript o'qiy olmaydi (XSS himoyasi).
- Refresh token DB'da **xeshlangan** holda saqlanadi — baza buzilsa ham token o'g'irlanmaydi.
- Har refreshda **rotatsiya**: eski token bekor qilinadi, yangisi beriladi.
- **Rate limit**: har IP daqiqada 100 so'rov.

## Keyingi qadam (Faza 1)
Profil + Post + Lenta + Like/Izoh. Media yuklash uchun Cloudflare R2 (signed URL) sozlanadi.
