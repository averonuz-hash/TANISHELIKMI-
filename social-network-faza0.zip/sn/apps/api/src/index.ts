import Fastify from "fastify";
import cors from "@fastify/cors";
import cookie from "@fastify/cookie";
import helmet from "@fastify/helmet";
import rateLimit from "@fastify/rate-limit";
import { env, isProd } from "./config/env.js";
import { authRoutes } from "./modules/auth/auth.routes.js";
import { userRoutes } from "./modules/users/users.routes.js";

const app = Fastify({
  logger: isProd ? true : { transport: { target: "pino-pretty" } },
});

// ── Xavfsizlik va infra plaginlari ─────────────────────────
await app.register(helmet);
await app.register(cors, {
  origin: env.CLIENT_ORIGIN,
  credentials: true, // cookie almashinuvi uchun zarur
});
await app.register(cookie);
await app.register(rateLimit, {
  max: 100, // har IP uchun daqiqada 100 so'rov (suiiste'molga qarshi)
  timeWindow: "1 minute",
});

// ── Sog'liq tekshiruvi (health check) ─────────────────────
app.get("/health", async () => ({ status: "ok", time: new Date().toISOString() }));

// ── Route'lar ──────────────────────────────────────────────
await app.register(authRoutes, { prefix: "/auth" });
await app.register(userRoutes, { prefix: "/users" });

// ── Ishga tushirish ────────────────────────────────────────
try {
  await app.listen({ port: env.PORT, host: "0.0.0.0" });
  console.log(`🚀 Server: http://localhost:${env.PORT}`);
} catch (err) {
  app.log.error(err);
  process.exit(1);
}
