import { FastifyInstance } from "fastify";
import { eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { users } from "../../db/schema.js";
import { authenticate } from "../../plugins/auth.js";

export async function userRoutes(app: FastifyInstance) {
  // GET /users/me — himoyalangan: joriy foydalanuvchi ma'lumotlari
  app.get("/me", { preHandler: [authenticate] }, async (req, reply) => {
    const [user] = await db
      .select({
        id: users.id,
        username: users.username,
        email: users.email,
        displayName: users.displayName,
        bio: users.bio,
        avatarUrl: users.avatarUrl,
        createdAt: users.createdAt,
      })
      .from(users)
      .where(eq(users.id, req.user!.sub))
      .limit(1);

    if (!user) return reply.code(404).send({ error: "Foydalanuvchi topilmadi" });
    return reply.send({ user });
  });
}
