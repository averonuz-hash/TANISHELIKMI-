import { z } from "zod";

export const registerSchema = z.object({
  username: z
    .string()
    .min(3, "Kamida 3 ta belgi")
    .max(32)
    .regex(/^[a-zA-Z0-9_]+$/, "Faqat harf, raqam va _ ruxsat etiladi"),
  email: z.string().email("Email noto'g'ri"),
  password: z.string().min(8, "Parol kamida 8 ta belgi bo'lsin").max(128),
  displayName: z.string().max(80).optional(),
});

export const loginSchema = z.object({
  // login orqali email yoki username bilan kirish mumkin
  identifier: z.string().min(1),
  password: z.string().min(1),
});

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
