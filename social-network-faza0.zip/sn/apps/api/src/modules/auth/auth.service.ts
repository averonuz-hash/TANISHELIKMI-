import { eq, or, and, isNull } from "drizzle-orm";
import { db } from "../../db/index.js";
import { users, refreshTokens } from "../../db/schema.js";
import { hashPassword, verifyPassword } from "../../utils/password.js";
import {
  signAccessToken,
  generateRefreshToken,
  hashToken,
  refreshExpiryDate,
} from "../../utils/tokens.js";
import type { RegisterInput, LoginInput } from "./auth.schema.js";

// Frontend'ga qaytariladigan xavfsiz foydalanuvchi obyekti (parolsiz)
function publicUser(u: typeof users.$inferSelect) {
  return {
    id: u.id,
    username: u.username,
    email: u.email,
    displayName: u.displayName,
    bio: u.bio,
    avatarUrl: u.avatarUrl,
    createdAt: u.createdAt,
  };
}

export class AuthError extends Error {
  constructor(public statusCode: number, message: string) {
    super(message);
  }
}

// Yangi access + refresh token juftligini yaratadi va refreshni DB'ga yozadi.
async function issueTokens(user: typeof users.$inferSelect) {
  const accessToken = signAccessToken({ sub: user.id, username: user.username });
  const refreshToken = generateRefreshToken();

  await db.insert(refreshTokens).values({
    userId: user.id,
    tokenHash: hashToken(refreshToken),
    expiresAt: refreshExpiryDate(),
  });

  return { accessToken, refreshToken };
}

export async function register(input: RegisterInput) {
  // username yoki email band emasligini tekshiramiz
  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(or(eq(users.username, input.username), eq(users.email, input.email)))
    .limit(1);

  if (existing.length > 0) {
    throw new AuthError(409, "Bu username yoki email allaqachon band");
  }

  const [user] = await db
    .insert(users)
    .values({
      username: input.username,
      email: input.email,
      passwordHash: await hashPassword(input.password),
      displayName: input.displayName ?? input.username,
    })
    .returning();

  const tokens = await issueTokens(user);
  return { user: publicUser(user), ...tokens };
}

export async function login(input: LoginInput) {
  const [user] = await db
    .select()
    .from(users)
    .where(or(eq(users.email, input.identifier), eq(users.username, input.identifier)))
    .limit(1);

  // Vaqt hujumiga (timing attack) qarshi: foydalanuvchi bo'lmasa ham
  // umumiy "noto'g'ri" xabarini qaytaramiz.
  if (!user || !(await verifyPassword(input.password, user.passwordHash))) {
    throw new AuthError(401, "Login yoki parol noto'g'ri");
  }

  const tokens = await issueTokens(user);
  return { user: publicUser(user), ...tokens };
}

// Refresh rotatsiyasi: eski tokenni bekor qilib, yangisini beramiz.
export async function refresh(rawRefreshToken: string) {
  const tokenHash = hashToken(rawRefreshToken);

  const [record] = await db
    .select()
    .from(refreshTokens)
    .where(and(eq(refreshTokens.tokenHash, tokenHash), isNull(refreshTokens.revokedAt)))
    .limit(1);

  if (!record || record.expiresAt < new Date()) {
    throw new AuthError(401, "Sessiya yaroqsiz, qayta kiring");
  }

  // Eski tokenni bekor qilamiz (rotation)
  await db
    .update(refreshTokens)
    .set({ revokedAt: new Date() })
    .where(eq(refreshTokens.id, record.id));

  const [user] = await db.select().from(users).where(eq(users.id, record.userId)).limit(1);
  if (!user) throw new AuthError(401, "Foydalanuvchi topilmadi");

  const tokens = await issueTokens(user);
  return { user: publicUser(user), ...tokens };
}

export async function logout(rawRefreshToken: string | undefined) {
  if (!rawRefreshToken) return;
  await db
    .update(refreshTokens)
    .set({ revokedAt: new Date() })
    .where(eq(refreshTokens.tokenHash, hashToken(rawRefreshToken)));
}
