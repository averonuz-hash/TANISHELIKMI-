import { FastifyInstance } from "fastify";
import { registerSchema, loginSchema } from "./auth.schema.js";
import * as authService from "./auth.service.js";
import { AuthError } from "./auth.service.js";
import {
  setRefreshCookie,
  clearRefreshCookie,
  REFRESH_COOKIE,
} from "../../plugins/auth.js";

export async function authRoutes(app: FastifyInstance) {
  // POST /auth/register
  app.post("/register", async (req, reply) => {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: parsed.error.flatten().fieldErrors });
    }
    try {
      const { user, accessToken, refreshToken } = await authService.register(parsed.data);
      setRefreshCookie(reply, refreshToken);
      return reply.code(201).send({ user, accessToken });
    } catch (err) {
      if (err instanceof AuthError) return reply.code(err.statusCode).send({ error: err.message });
      throw err;
    }
  });

  // POST /auth/login
  app.post("/login", async (req, reply) => {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: parsed.error.flatten().fieldErrors });
    }
    try {
      const { user, accessToken, refreshToken } = await authService.login(parsed.data);
      setRefreshCookie(reply, refreshToken);
      return reply.send({ user, accessToken });
    } catch (err) {
      if (err instanceof AuthError) return reply.code(err.statusCode).send({ error: err.message });
      throw err;
    }
  });

  // POST /auth/refresh — cookie'dagi refresh token bilan yangi access oladi
  app.post("/refresh", async (req, reply) => {
    const raw = req.cookies[REFRESH_COOKIE];
    if (!raw) return reply.code(401).send({ error: "Refresh token yo'q" });
    try {
      const { user, accessToken, refreshToken } = await authService.refresh(raw);
      setRefreshCookie(reply, refreshToken);
      return reply.send({ user, accessToken });
    } catch (err) {
      if (err instanceof AuthError) {
        clearRefreshCookie(reply);
        return reply.code(err.statusCode).send({ error: err.message });
      }
      throw err;
    }
  });

  // POST /auth/logout
  app.post("/logout", async (req, reply) => {
    await authService.logout(req.cookies[REFRESH_COOKIE]);
    clearRefreshCookie(reply);
    return reply.send({ ok: true });
  });
}
