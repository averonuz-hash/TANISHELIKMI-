import { FastifyReply, FastifyRequest } from "fastify";
import { verifyAccessToken, AccessTokenPayload } from "../utils/tokens.js";
import { env, isProd } from "../config/env.js";

// Request'ga foydalanuvchi ma'lumotini qo'shamiz (type kengaytirish)
declare module "fastify" {
  interface FastifyRequest {
    user?: AccessTokenPayload;
  }
}

export const REFRESH_COOKIE = "refresh_token";

// Himoyalangan route'lar uchun: `preHandler: [authenticate]`
export async function authenticate(req: FastifyRequest, reply: FastifyReply) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    return reply.code(401).send({ error: "Avtorizatsiya talab qilinadi" });
  }
  const token = header.slice(7);
  try {
    req.user = verifyAccessToken(token);
  } catch {
    return reply.code(401).send({ error: "Token yaroqsiz yoki muddati o'tgan" });
  }
}

// Refresh tokenni httpOnly cookie sifatida o'rnatamiz —
// JavaScript bu cookie'ni o'qiy olmaydi (XSS himoyasi).
export function setRefreshCookie(reply: FastifyReply, token: string) {
  reply.setCookie(REFRESH_COOKIE, token, {
    httpOnly: true,
    secure: isProd,
    sameSite: "lax",
    domain: env.COOKIE_DOMAIN,
    path: "/auth",
    maxAge: env.REFRESH_TOKEN_TTL_DAYS * 24 * 60 * 60,
  });
}

export function clearRefreshCookie(reply: FastifyReply) {
  reply.clearCookie(REFRESH_COOKIE, { path: "/auth", domain: env.COOKIE_DOMAIN });
}
