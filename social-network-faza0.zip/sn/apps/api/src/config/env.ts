import "dotenv/config";
import { z } from "zod";

// .env qiymatlarini tekshirib, type-safe qilib beramiz.
// Noto'g'ri konfiguratsiya bilan server umuman ishga tushmasligi kerak.
const schema = z.object({
  PORT: z.coerce.number().default(4000),
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  DATABASE_URL: z.string().url(),
  JWT_ACCESS_SECRET: z.string().min(32),
  JWT_REFRESH_SECRET: z.string().min(32),
  ACCESS_TOKEN_TTL: z.string().default("15m"),
  REFRESH_TOKEN_TTL_DAYS: z.coerce.number().default(30),
  CLIENT_ORIGIN: z.string().url().default("http://localhost:3000"),
  COOKIE_DOMAIN: z.string().default("localhost"),
});

const parsed = schema.safeParse(process.env);

if (!parsed.success) {
  console.error("❌ Noto'g'ri muhit o'zgaruvchilari (.env):");
  console.error(parsed.error.flatten().fieldErrors);
  process.exit(1);
}

export const env = parsed.data;
export const isProd = env.NODE_ENV === "production";
