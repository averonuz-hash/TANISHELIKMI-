import { drizzle } from "drizzle-orm/node-postgres";
import pkg from "pg";
import { env } from "../config/env.js";
import * as schema from "./schema.js";

const { Pool } = pkg;

// Ulanish puli (connection pool) — har so'rovda yangi ulanish ochmaymiz.
export const pool = new Pool({
  connectionString: env.DATABASE_URL,
  max: 10,
});

export const db = drizzle(pool, { schema });
export { schema };
