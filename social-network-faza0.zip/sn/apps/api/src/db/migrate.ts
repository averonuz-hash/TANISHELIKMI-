import { migrate } from "drizzle-orm/node-postgres/migrator";
import { db, pool } from "./index.js";

// Migratsiyalarni qo'llaydi. `pnpm db:generate` bilan yaratilgan
// SQL fayllarni `./drizzle` papkasidan o'qiydi.
async function main() {
  console.log("⏳ Migratsiyalar qo'llanmoqda...");
  await migrate(db, { migrationsFolder: "./drizzle" });
  console.log("✅ Migratsiyalar tugadi.");
  await pool.end();
  process.exit(0);
}

main().catch((err) => {
  console.error("❌ Migratsiya xatosi:", err);
  process.exit(1);
});
