#!/usr/bin/env bash
# Poydevorni avtomatik sinaydi: register → me → logout → refresh.
# Server ishlab turganda ishga tushiring:  bash smoke-test.sh
set -euo pipefail

BASE="${BASE:-http://localhost:4000}"
JAR="$(mktemp)"
RAND=$RANDOM
USER="test_$RAND"
EMAIL="test_$RAND@example.com"
PASS="parol12345"

green() { printf "\033[32m✓ %s\033[0m\n" "$1"; }
red()   { printf "\033[31m✗ %s\033[0m\n" "$1"; exit 1; }

echo "── 1. Health check ──"
curl -fsS "$BASE/health" >/dev/null && green "Server javob beryapti" || red "Server javob bermayapti"

echo "── 2. Register ──"
REG=$(curl -fsS -c "$JAR" -X POST "$BASE/auth/register" \
  -H "Content-Type: application/json" \
  -d "{\"username\":\"$USER\",\"email\":\"$EMAIL\",\"password\":\"$PASS\"}")
ACCESS=$(echo "$REG" | grep -o '"accessToken":"[^"]*"' | cut -d'"' -f4)
[ -n "$ACCESS" ] && green "Ro'yxatdan o'tildi, access token olindi" || red "Register muvaffaqiyatsiz"

echo "── 3. Himoyalangan /users/me ──"
ME=$(curl -fsS "$BASE/users/me" -H "Authorization: Bearer $ACCESS")
echo "$ME" | grep -q "$USER" && green "Himoyalangan endpoint ishladi" || red "/me muvaffaqiyatsiz"

echo "── 4. Token yo'q bilan /me (401 kutiladi) ──"
CODE=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/users/me")
[ "$CODE" = "401" ] && green "Tokensiz to'g'ri rad etildi (401)" || red "Xavfsizlik xatosi: $CODE"

echo "── 5. Refresh (cookie bilan) ──"
REF=$(curl -fsS -b "$JAR" -c "$JAR" -X POST "$BASE/auth/refresh")
NEW=$(echo "$REF" | grep -o '"accessToken":"[^"]*"' | cut -d'"' -f4)
[ -n "$NEW" ] && green "Refresh ishladi, yangi token olindi" || red "Refresh muvaffaqiyatsiz"

echo "── 6. Login ──"
LOG=$(curl -fsS -c "$JAR" -X POST "$BASE/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"identifier\":\"$EMAIL\",\"password\":\"$PASS\"}")
echo "$LOG" | grep -q "accessToken" && green "Login ishladi" || red "Login muvaffaqiyatsiz"

echo "── 7. Logout ──"
curl -fsS -b "$JAR" -X POST "$BASE/auth/logout" >/dev/null && green "Logout ishladi" || red "Logout muvaffaqiyatsiz"

rm -f "$JAR"
printf "\n\033[32m🎉 Hammasi o'tdi — poydevor ishlayapti!\033[0m\n"
