#!/usr/bin/env bash
# Poydevorni to'liq tayyorlaydi. Loyiha ildizida ishga tushiring:  bash setup.sh
set -euo pipefail
cd "$(dirname "$0")"

echo "🔧 Ijtimoiy tarmoq — Faza 0 sozlash"

# 1. Talablarni tekshirish
command -v docker >/dev/null || { echo "❌ Docker o'rnatilmagan"; exit 1; }
command -v pnpm   >/dev/null || { echo "❌ pnpm o'rnatilmagan (npm i -g pnpm)"; exit 1; }

# 2. PostgreSQL ko'tarish
echo "🐘 PostgreSQL ishga tushirilmoqda..."
docker compose up -d postgres
echo "⏳ Baza tayyor bo'lishini kutyapmiz..."
until docker exec sn-postgres pg_isready -U postgres >/dev/null 2>&1; do sleep 1; done
echo "✅ PostgreSQL tayyor"

# 3. .env yaratish (xavfsiz random sirlar bilan)
ENV_FILE="apps/api/.env"
if [ ! -f "$ENV_FILE" ]; then
  echo "🔑 .env yaratilmoqda (random JWT sirlari bilan)..."
  ACCESS_SECRET=$(openssl rand -hex 32)
  REFRESH_SECRET=$(openssl rand -hex 32)
  sed -e "s|change_me_access_secret_min_32_chars_long|$ACCESS_SECRET|" \
      -e "s|change_me_refresh_secret_min_32_chars_long|$REFRESH_SECRET|" \
      apps/api/.env.example > "$ENV_FILE"
  echo "✅ .env yaratildi"
else
  echo "ℹ️  .env allaqachon mavjud, o'tkazib yuborildi"
fi

# 4. Bog'liqliklar
echo "📦 Bog'liqliklar o'rnatilmoqda..."
pnpm install

# 5. Migratsiya
echo "🗃️  Migratsiya yaratilmoqda va qo'llanmoqda..."
pnpm --filter @sn/api db:generate
pnpm --filter @sn/api db:migrate

echo ""
echo "🎉 Tayyor! Endi serverni ishga tushiring:"
echo "    pnpm dev:api"
echo ""
echo "Keyin boshqa terminalda sinab ko'ring:"
echo "    bash smoke-test.sh"
